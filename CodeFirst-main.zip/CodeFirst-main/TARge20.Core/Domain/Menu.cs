﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Menu
    {
        public Guid ID { get; set; }
        public DateTime Date { get; set; }
        public string dishes { get; set; }

    }
}
