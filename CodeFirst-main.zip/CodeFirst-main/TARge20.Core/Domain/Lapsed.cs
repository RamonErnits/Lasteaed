﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Lapsed
    {
        public Guid Id { get; set; }

        public string Kids_name { get; set; }
        public string Kids_lastname { get;set; }
        public string Parent_name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }



    }
}
